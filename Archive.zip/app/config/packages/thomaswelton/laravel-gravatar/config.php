<?php

return array(
    'size' => 80,
    'default' => 'identicon',
    'maxRating' => 'g'
);
