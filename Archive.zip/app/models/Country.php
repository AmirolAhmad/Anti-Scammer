<?php

class Country extends Eloquent {
	
}