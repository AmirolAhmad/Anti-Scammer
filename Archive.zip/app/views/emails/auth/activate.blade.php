Hello {{ $fullname }},<br /><br />

Please activate your account by clicking on the link below:- <br /><br />

---<br />
{{ $link }}<br />
---