Hello {{ $fullname }},<br /><br />

It looks like you have requested a new password. You'll need to click the following link in order to activate your new password. If you didn't request a new password before, please ignore this email.<br /><br />

---<br />
{{ $link }}<br />
---<br /><br />

New password: {{ $password }}<br />